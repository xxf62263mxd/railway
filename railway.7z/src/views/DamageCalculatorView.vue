<template>
  <section class="section">
    <div class="container">
      <div class="columns">
        <div class="column">
          <div class="box">

            <b-table
                :data="attrTableData"
                :checked-rows.sync="checkedRows"
                checkable
                focusable
                :checkbox-position="checkboxPosition"
                :checkbox-type="checkboxType"
                @mouseenter="mouseEnter"
                @mouseleave="mouseLeave"
                >
              <b-table-column v-for="(column,index) in columns" :key="index" v-slot="props"
                              :field="column.field" :label="column.label" :width="column.width">
                <template v-if="column.isButton">
                  <p class="control" v-if="props.row.attr_del_show">
                    <b-button type="is-danger"
                              size="is-small"
                              icon-right="delete" />
                  </p>
                </template>
                <template v-else>
                  {{props.row[column.field]}}
                </template>
              </b-table-column>

            </b-table>


            <b-field style="margin-top: 30px">
              <b-select :value="2">
                <option v-for="item in attrCategories" :key="item.id" :value="item.id">
                  {{item.name}}
                </option>
              </b-select>
              <b-input type="number" placeholder="1000"></b-input>
              <p class="control">
                <b-button type="is-primary" label="添加" />
              </p>
            </b-field>

            <p class="control">
              <b-button type="is-primary" label="添加" />
            </p>
          </div>
        </div>

        <div class="column">
          <div class="box">
            <h2 class="subtitle">战力指示图</h2>

          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: "DamageCalculatorView",
  methods: {
    getAttrCategoryName(attr_id) {

      for (let i in this.attrCategories) {
        if (i.id === attr_id) {
          return i.name
        }
      }

    },
    mouseEnter(row,event) {
      row.attr_del_show = true
    },
    mouseLeave(row,event) {
      row.attr_del_show = false
    }
  },
  data() {
    const attrCategories = [
      {'id':0,'name':'初始攻击力'},
      {'id':1,'name':'技能倍率'},
      {'id':2,'name':'攻击力固定值'},
      {'id':3,'name':'攻击力百分比'},
    ]

    const attrTableData = [
      {'attr_id':0,'attr_name':'初始攻击力','attr_value':1600,'attr_note':'攻击力面板白值','attr_del_show':false},
      {'attr_id':1,'attr_name':'技能倍率','attr_value':400,'attr_note':'','attr_del_show':false},
    ]

    return {
      attrCategories,
      attrTableData,
      checkboxPosition: 'left',
      checkboxType: 'is-primary',
      checkedRows: [attrTableData[0], attrTableData[1]],
      columns: [
        {
          field: 'attr_name',
          label: '属性名',
          isButton:false,
        },
        {
          field: 'attr_value',
          label: '属性值',
          numeric: true,
          centered: true,
          isButton:false,
        },
        {
          field: 'attr_note',
          label: '备注',
          isButton:false,
        },
        {
          field: 'attr_del',
          label: ' ',
          width:'100',
          isButton:true,
        }
      ]
    }
  }
}
</script>

<style scoped>
</style>